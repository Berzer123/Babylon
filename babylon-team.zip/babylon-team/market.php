<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Babylon-team</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/market.css">
</head>
<body>
<?php require "header.php" ?>
    <div class="container-filter">
        <div class="box-filter">
            <div class="h-filter">
                <p>Фильтры</p>
            </div>
        </div>

    </div>
    <div class="container-filter">
        <div class="filter-list">
            <p>Заголовок</p>
            <div>
                <input type="text" placeholder="От">
                <input type="text" placeholder="До">
            </div>
            <p>Заголовок</p>
            <div>
                <input type="text" placeholder="От">
                <input type="text" placeholder="До">
            </div>
            
        </div>
        <div class="filter-list">
            <p>Заголовок</p>
            <div>
                <input type="text" placeholder="От">
                <input type="text" placeholder="До">
            </div>
            <p>Заголовок</p>
            <div>
                <input type="text" placeholder="От">
                <input type="text" placeholder="До">
            </div>
            
        </div>
        <div class="filter-list">
            <p>Заголовок</p>
            <div>
                <input type="text" placeholder="От">
                <input type="text" placeholder="До">
            </div>
            <p>Заголовок</p>
            <div>
                <input type="text" placeholder="От">
                <input type="text" placeholder="До">
            </div>
            
        </div>
        <div class="filter-list">
            <p>Заголовок</p>
            <div>
                <input type="text" placeholder="От">
                <input type="text" placeholder="До">
            </div>
            <p>Заголовок</p>
            <div>
                <input type="text" placeholder="От">
                <input type="text" placeholder="До">
            </div>
            
        </div>
        
    </div>
    <div class="container-filter">
        <div class="button-filter">
            <div class="rating">
                <button>Рейтинг</button>
            </div>
            <div class="price">
                <button>Цена</button>
            </div>
            <div class="rank">
                <button>Ранг</button>
            </div>
        </div>
    </div>

    <div class="cards-list">
        <div class="container-card">

            <div class="card">
                <div class="card-border">
                    <img class="img-border" src="img/invoker.png" alt="" >
                    <div class="card-desc">
                        <div class="card-name">Название товара</div>
                        <div class="card-price">$999999</div>
                    </div>
                    <div class="option-button">
                        <img class="logo-user" src="img/berzer-logo.jpg" alt="" >
                        <img class="icon-basket" src="img/Сгруппировать 118.svg" alt="">
                        <button>Купить</button>
                    </div>

                </div>
                
            </div>
            <div class="card">
                <div class="card-border">
                    <img class="img-border" src="img/invoker.png" alt="" >
                    <div class="card-desc">
                        <div class="card-name">Название товара</div>
                        <div class="card-price">$999999</div>
                    </div>
                    <div class="option-button">
                        <img class="logo-user" src="img/berzer-logo.jpg" alt="" >
                        <img class="icon-basket" src="img/Сгруппировать 118.svg" alt="">
                        <button>Купить</button>
                    </div>

                </div>
                
            </div>
            <div class="card">
                <div class="card-border">
                    <img class="img-border" src="img/invoker.png" alt="" >
                    <div class="card-desc">
                        <div class="card-name">Название товара</div>
                        <div class="card-price">$999999</div>
                    </div>
                    <div class="option-button">
                        <img class="logo-user" src="img/berzer-logo.jpg" alt="" >
                        <img class="icon-basket" src="img/Сгруппировать 118.svg" alt="">
                        <button>Купить</button>
                    </div>

                </div>
                
            </div>
            <div class="card">
                <div class="card-border">
                    <img class="img-border" src="img/invoker.png" alt="" >
                    <div class="card-desc">
                        <div class="card-name">Название товара</div>
                        <div class="card-price">$999999</div>
                    </div>
                    <div class="option-button">
                        <img class="logo-user" src="img/berzer-logo.jpg" alt="" >
                        <img class="icon-basket" src="img/Сгруппировать 118.svg" alt="">
                        <button>Купить</button>
                    </div>

                </div>
                
            </div>

        </div>
        <div class="container-card">

            <div class="card">
                <div class="card-border">
                    <img class="img-border" src="img/invoker.png" alt="" >
                    <div class="card-desc">
                        <div class="card-name">Название товара</div>
                        <div class="card-price">$999999</div>
                    </div>
                    <div class="option-button">
                        <img class="logo-user" src="img/berzer-logo.jpg" alt="" >
                        <img class="icon-basket" src="img/Сгруппировать 118.svg" alt="">
                        <button>Купить</button>
                    </div>

                </div>
                
            </div>
            <div class="card">
                <div class="card-border">
                    <img class="img-border" src="img/invoker.png" alt="" >
                    <div class="card-desc">
                        <div class="card-name">Название товара</div>
                        <div class="card-price">$999999</div>
                    </div>
                    <div class="option-button">
                        <img class="logo-user" src="img/berzer-logo.jpg" alt="" >
                        <img class="icon-basket" src="img/Сгруппировать 118.svg" alt="">
                        <button>Купить</button>
                    </div>

                </div>
                
            </div>
            <div class="card">
                <div class="card-border">
                    <img class="img-border" src="img/invoker.png" alt="" >
                    <div class="card-desc">
                        <div class="card-name">Название товара</div>
                        <div class="card-price">$999999</div>
                    </div>
                    <div class="option-button">
                        <img class="logo-user" src="img/berzer-logo.jpg" alt="" >
                        <img class="icon-basket" src="img/Сгруппировать 118.svg" alt="">
                        <button>Купить</button>
                    </div>

                </div>
                
            </div>
            <div class="card">
                <div class="card-border">
                    <img class="img-border" src="img/invoker.png" alt="" >
                    <div class="card-desc">
                        <div class="card-name">Название товара</div>
                        <div class="card-price">$999999</div>
                    </div>
                    <div class="option-button">
                        <img class="logo-user" src="img/berzer-logo.jpg" alt="" >
                        <img class="icon-basket" src="img/Сгруппировать 118.svg" alt="">
                        <button>Купить</button>
                    </div>

                </div>
                
            </div>

        </div>
        <div class="container-card">

            <div class="card">
                <div class="card-border">
                    <img class="img-border" src="img/invoker.png" alt="" >
                    <div class="card-desc">
                        <div class="card-name">Название товара</div>
                        <div class="card-price">$999999</div>
                    </div>
                    <div class="option-button">
                        <img class="logo-user" src="img/berzer-logo.jpg" alt="" >
                        <img class="icon-basket" src="img/Сгруппировать 118.svg" alt="">
                        <button>Купить</button>
                    </div>

                </div>
                
            </div>
            <div class="card">
                <div class="card-border">
                    <img class="img-border" src="img/invoker.png" alt="" >
                    <div class="card-desc">
                        <div class="card-name">Название товара</div>
                        <div class="card-price">$999999</div>
                    </div>
                    <div class="option-button">
                        <img class="logo-user" src="img/berzer-logo.jpg" alt="" >
                        <img class="icon-basket" src="img/Сгруппировать 118.svg" alt="">
                        <button>Купить</button>
                    </div>

                </div>
                
            </div>
            <div class="card">
                <div class="card-border">
                    <img class="img-border" src="img/invoker.png" alt="" >
                    <div class="card-desc">
                        <div class="card-name">Название товара</div>
                        <div class="card-price">$999999</div>
                    </div>
                    <div class="option-button">
                        <img class="logo-user" src="img/berzer-logo.jpg" alt="" >
                        <img class="icon-basket" src="img/Сгруппировать 118.svg" alt="">
                        <button>Купить</button>
                    </div>

                </div>
                
            </div>
            <div class="card">
                <div class="card-border">
                    <img class="img-border" src="img/invoker.png" alt="" >
                    <div class="card-desc">
                        <div class="card-name">Название товара</div>
                        <div class="card-price">$999999</div>
                    </div>
                    <div class="option-button">
                        <img class="logo-user" src="img/berzer-logo.jpg" alt="" >
                        <img class="icon-basket" src="img/Сгруппировать 118.svg" alt="">
                        <button>Купить</button>
                    </div>

                </div>
                
            </div>

        </div>
        <div class="container-card">

            <div class="card">
                <div class="card-border">
                    <img class="img-border" src="img/invoker.png" alt="" >
                    <div class="card-desc">
                        <div class="card-name">Название товара</div>
                        <div class="card-price">$999999</div>
                    </div>
                    <div class="option-button">
                        <img class="logo-user" src="img/berzer-logo.jpg" alt="" >
                        <img class="icon-basket" src="img/Сгруппировать 118.svg" alt="">
                        <button>Купить</button>
                    </div>

                </div>
                
            </div>
            <div class="card">
                <div class="card-border">
                    <img class="img-border" src="img/invoker.png" alt="" >
                    <div class="card-desc">
                        <div class="card-name">Название товара</div>
                        <div class="card-price">$999999</div>
                    </div>
                    <div class="option-button">
                        <img class="logo-user" src="img/berzer-logo.jpg" alt="" >
                        <img class="icon-basket" src="img/Сгруппировать 118.svg" alt="">
                        <button>Купить</button>
                    </div>

                </div>
                
            </div>
            <div class="card">
                <div class="card-border">
                    <img class="img-border" src="img/invoker.png" alt="" >
                    <div class="card-desc">
                        <div class="card-name">Название товара</div>
                        <div class="card-price">$999999</div>
                    </div>
                    <div class="option-button">
                        <img class="logo-user" src="img/berzer-logo.jpg" alt="" >
                        <img class="icon-basket" src="img/Сгруппировать 118.svg" alt="">
                        <button>Купить</button>
                    </div>

                </div>
                
            </div>
            <div class="card">
                <div class="card-border">
                    <img class="img-border" src="img/invoker.png" alt="" >
                    <div class="card-desc">
                        <div class="card-name">Название товара</div>
                        <div class="card-price">$999999</div>
                    </div>
                    <div class="option-button">
                        <img class="logo-user" src="img/berzer-logo.jpg" alt="" >
                        <img class="icon-basket" src="img/Сгруппировать 118.svg" alt="">
                        <button>Купить</button>
                    </div>

                </div>
                
            </div>

        </div>
    </div>
    <div class="container-card">
        <div class="pagination">
            <div class="next"><button><</button></div>
            <div class="button-list">
                <button>1</button>
                <button>2</button>
                <button>3</button>
            </div>
            <div class="prev"><button>></button></div>
        </div>
    </div>

    <?php require "footer.php" ?>
</body>
</html>