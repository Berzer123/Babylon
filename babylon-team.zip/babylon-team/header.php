<?php
session_start();
?>
<link rel="stylesheet" href="css/header.css">
<div class="menu">
        <div class="container">
            <div class="nav">
                <ul class="nav-list">
                    <li><a href="#1">Услуги</a></li>
                    <li><a href="#2">О нас</a></li>
                    <li><a href="#3">Поддержка</a></li>
                    <li><a href="#4">Контакты</a></li>
                </ul>
            </div>

            <?php //проверка на сессию и соответствующий вид хедера
       if (!empty($_SESSION['auth'])): ?>
       <div class="nav-list">
        <p class="nav-item"><?php echo $_SESSION['username']; ?></p>
        
    
      <a class="nav-item" href="php/logoutsp.php">Выйти</a>

       </div>
       
      <?php else: ?>
        <div class="icon">
                <div class="login"><a href="login.php"><img src="img/Сгруппировать 136.svg" alt=""></a></div>
                <div class="basket"><img src="img/Сгруппировать 139.svg" alt=""></div>
        </div>
            
      <?php endif; ?>
      </div>
            
    </div>
<div>