<?php
$url = '../main.php';
session_start();
$_SESSION['auth'] = null;
header('Location: ' . $url);
session_destroy();
?>