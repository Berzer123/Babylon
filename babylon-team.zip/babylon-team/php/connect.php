<?php
    $host = 'localhost';
    $user = 'root';
    $password = '';
    $db_name = 'vavilon';
    
    $link = mysqli_connect($host, $user, $password, $db_name);

?>