<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Babylon-team</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
<?php require "header.php" ?>

    <div class="container">
        <div class="reg-img">
            <img src="img/Регистрация.png" alt="">
        </div>
        
    </div>

    <div class="container">
        <form action="php/loginsp.php" method="post">
            <div class="input-list">
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Пароль" required>
                <button>Войти</button>
                <input type="submit" class="btn" value="Войти">
            </div>
            
        </form>
    </div>



    <div class="container">
        <form action="php/reg-save.php" method="post">
            <div class="input-list">
                <input type="text" name="username" placeholder="username" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Пароль" required>
                <button>Зарегестрироваться</button>
                <input type="submit" class="btn" value="Зарегистрироваться">
            </div>
            
        </form>
    </div>


    <?php require "footer.php" ?>
</body>
</html>