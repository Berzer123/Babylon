<footer>
        <div class="footer-text">Copyright © 2023 Created by Babylon team. </div>
    </footer>