<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Babylon-team</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
</head>
<body>

    <?php require "header.php" ?>

    <div class="main">
        <div class="container2">
            <div class="text">
                <div class="h1-text">
                    <img src="img/баннр_верх.png" alt="" width="520">
                    <div class="centered">Буст рейтинга <br> от <br> профессионалов</div>
                    
                </div>

                    <div class="button">
                        <a href="market.php">Купить</a>
                    </div>

            </div>
            <div class="main-pic">
                <img src="img/mainpic.png" alt="" width="1034">
                <a name="1"></a>
            </div>
        </div>
            
    </div>
    <div class="services">
        <div class="container">
            <div class="img-services">
                <div class="services"><img src="img/services.png" alt=""></div>
            </div>
        
            
                
        </div>
        <div class="container">
            <div class="item">
                <div class="img1"><img src="img/wraith.png" alt=""></div>
                <div class="img1"><img src="img/invoker.png" alt=""></div>
                <div class="img1"><img src="img/TRACER2.png" alt=""></div>
                
            </div>
        </div>
        
        
    </div>

    <div class="container">
        <div class="about-us">
            <div class="img-about-us">
                <img src="img/О нас.png" alt="">
                <a name="2"></a>
            </div>
            
        </div>
    </div>
    <div class="text-about-us">
        <div><hr class="line1" width="50%" align="right"></div>
        <p class="text-about-1">
            Наша компания - это место, где вы можете купить или продать аккаунты в таких популярных играх, как Dota 2, Overwatch и Apex Legends. Мы предлагаем широкий выбор аккаунтов разного уровня и рейтинга, чтобы удовлетворить потребности любого игрока. Мы также предоставляем услуги по бусту рейтинга в играх, чтобы помочь вам достичь желаемого уровня и стать лучшим игроком в своей команде. Наша команда профессиональных игроков использует только самые эффективные методы и стратегии, чтобы гарантировать быстрый и безопасный буст рейтинга. 
        </p>
        <p class="text-about-2">
            Наша компания основана на принципах честности, надежности и качественного обслуживания. Мы также предлагаем конкурентоспособные цены и быструю доставку. Если вы хотите продать свой аккаунт, мы готовы предложить вам лучшую цену на рынке. Мы стремимся обеспечить нашим клиентам лучший опыт игры Обратитесь к нам сегодня и получите высококачественные услуги по продаже и покупке аккаунтов, а также бусту рейтинга в играх.Мы также предоставляем услуги по бусту рейтинга в играх, чтобы помочь вам достичь желаемого уровня.
        </p>
        <div><hr class="line2" width="45%" align="left"></div>
        
    </div>
    <a name="3"></a>
    <div class="suport">
        <div class="container">
            <div class="h2-support">
                <img src="img/Поддержка.png" alt="">
            </div>
            
        </div>
        
        <div class="text-support">
            <p>
                тут будет онлайн-чат с питона, если мне будет скучно конечно Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestiae eveniet quod delectus facilis nesciunt error a repellat blanditiis dignissimos consequuntur voluptate consequatur, soluta quaerat ipsum placeat ducimus earum dolorum aliquid dicta vero quas? Eligendi fuga fugit magni tenetur. Nam, vel sunt. Consequuntur enim eveniet impedit minima veritatis saepe, voluptas sunt?
            </p>
        </div>
    </div>
    
    <div class="contact">
        <div class="container">
            <div class="img-contact"><img src="img/Контакты.png" alt=""></div>
            <a name="4"></a>
        </div>
        <div class="container-contact">
            <div class="contact-list">
                <div class="pos-name">
                    <img src="img/Дизайн.png" alt="">
                </div>
                <div class="pos-qr">
                    <img src="img/Федя.png" alt="" width="350" height="460">
                </div>
                <div class="pos=text">

                </div>
            </div>
            <div class="contact-list">
                <div class="pos-name">
                    <img src="img/Верстка.png" alt="">
                </div>
                <div class="pos-qr">
                    <img src="img/Левон22.png" alt="" width="350" height="460">
                </div>
                <div class="pos=text">
                    
                </div>
            </div>
            <div class="contact-list">
                <div class="pos-name">
                    <img src="img/Back-end.png" alt="">
                </div>
                <div class="pos-qr">
                    <img src="img/Никита.png" alt="" width="350" height="460">
                </div>
                <div class="pos=text">
                    
                </div>
            </div>
            
        </div>
        
        
    </div>

    <?php require "footer.php" ?>
</body>
</html>